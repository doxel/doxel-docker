var sceneProperties = {
	path: "../resources/pointclouds/potree/cloud.js",
	cameraPosition: null, 		// other options: cameraPosition: [10,10,10],
	cameraTarget: null, 		// other options: cameraTarget: [0,0,0],
	fov: 60, 					// field of view in degrees,
	sizeType: "Fixed",	// other options: "Fixed", "Attenuated"
	quality: null, 			// other options: "Circles", "Interpolation", "Splats"
	material: "RGB", 		// other options: "Height", "Intensity", "Classification"
	pointLimit: 1,				// max number of points in millions
	pointSize: 1,				// 
	navigation: "Orbit",		// other options: "Orbit", "Flight"
	useEDL: false,				
};
sceneProperties.cameraPosition= [ -0.013715461734918048,
  -0.01982873700343056,
  -0.032628002877303365 ] ;
sceneProperties.cameraTarget= [ -0.007409675535467347,
  -0.009522588964689077,
  0.9672990046452509 ] ;
sceneProperties.cameraUp= [ 0.0034375148455342403,
  -0.9999412033486564,
  0.010284616537715837 ] ;
